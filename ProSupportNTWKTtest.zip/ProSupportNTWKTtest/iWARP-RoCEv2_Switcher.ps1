﻿<# You running this script/function means you will not blame the author(s) if this breaks your stuff. 
This script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied 
warranties including, without limitation, any implied warranties of merchantability or of fitness for
 a particular purpose. The entire risk arising out of the use or performance of the sample scripts 
 and documentation remains with you. In no event shall author(s) be held liable for any damages 
 whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
 loss of business information, or other pecuniary loss) arising out of the use of or inability to use 
 the script or documentation. Neither this script/function, nor any part of it other than those parts that 
 are explicitly copied from others, may be republished without author(s) express written permission. 
 Author(s) retain the right to alter this disclaimer at any time. For the most up to date version of 
 the disclaimer

 #>

# Convert LAB S2D Cluster between iWARP and RoCRv2 
    $Ver="v1.0"
    $Loop3times=0
    CLS
    Function EndScript{  
        break script 
    }
    do{
        Write-Host "Which type of RDMA do you wish to configure, iWARP or ROCEv2?"
        $Loop3times=$Loop3times+1
        $RDMAType2Configure = Read-Host "Please only type either iWARP or RoCE"}
    until ($RDMAType2Configure -match 'iWARP' -or $RDMAType2Configure -match 'RoCE' -or $Loop3times -eq 3)
    if($Loop3times -GT 2){
        Write-Error "ERROR: Invalid entry. Not able to find iWARP or RoCE three times. Exiting..."
        EndScript
    }
    

# iWARP
IF($RDMAType2Configure -imatch 'iWARP'){
    Invoke-Command -ComputerName (Get-ClusterNode -Cluster (Get-Cluster).Name) -ScriptBlock { 
        # Remove QOS Policy
            Remove-NetQosPolicy 'SMB', 'Cluster' -Confirm:$false
        # Remove QOS Traffic Class
            Remove-NetQosTrafficClass 'SMB', 'Cluster' -Confirm:$false
        # Default Net Qos Flow Control
            Disable-NetQosFlowControl –Priority 0,1,2,3,4,5,6,7 -Confirm:$false
        # Default DCBX Willing mode
            Set-NetQosDcbxSetting -Willing $True -Confirm:$false
        # Disable QLogic Nix            Enable-NetAdapter -Name $(Get-NetAdapter -InterfaceDescription "QLogic FastLinQ QL41262*").name -Confirm:$false
            Get-NetAdapter -InterfaceDescription "QLogic FastLinQ QL41262*"
        # Disable Mellanox Nix            Disable-NetAdapter -Name $(Get-NetAdapter -InterfaceDescription "Mellanox ConnectX*").name -Confirm:$false
            Get-NetAdapter -InterfaceDescription "Mellanox ConnectX*"
    }
}

# RoCRv2
IF($RDMAType2Configure -imatch 'RoCE'){
    Invoke-Command -ComputerName (Get-ClusterNode -Cluster (Get-Cluster).Name) -ScriptBlock { 

        # RoCE RDMA QOS setting for nodes
            # Fin Mx NICs
            $StorageAdapters = $(Get-NetAdapter -InterfaceDescription "Mellanox ConnectX*").name
            # New QoS policy with a match condition set to 445 (TCP Port 445 is dedicated for SMB)
            # Arguments 3 and 5 to the PriorityValue8021Action parameter indicate the IEEE802.1p 
            # values for SMB and cluster traffic.
                New-NetQosPolicy -Name 'SMB' –NetDirectPortMatchCondition 445 –PriorityValue8021Action 3 -Confirm:$false
                New-NetQosPolicy -Name 'Cluster' -Cluster -PriorityValue8021Action 5 -Confirm:$false
            # Map the IEEE 802.1p priority enabled in the system to a traffic class
                New-NetQosTrafficClass -Name 'SMB' –Priority 3 –BandwidthPercentage 50 –Algorithm ETS -Confirm:$false
                New-NetQosTrafficClass -Name 'Cluster' –Priority 5 –BandwidthPercentage 1 –Algorithm ETS -Confirm:$false
            # Configure flow control for the priorities shown in the above table
                Enable-NetQosFlowControl –Priority 3,5 -Confirm:$false
                Disable-NetQosFlowControl –Priority 0,1,2,4,6,7 -Confirm:$false
            # Enable QoS for the Mellanox network adapter ports.
                foreach ($port in $StorageAdapterName) {
                    Enable-NetAdapterQos –InterfaceAlias $port -Confirm:$false
                    Set-NetAdapterAdvancedProperty -Name $port -DisplayName 'DcbxMode' -DisplayValue 'Host In Charge' -Confirm:$false
                }
            # Disable DCBX Willing mode
                Set-NetQosDcbxSetting -Willing $false -Confirm:$false        # Enable Mellanox Nix            Enable-NetAdapter -Name $(Get-NetAdapter -InterfaceDescription "Mellanox ConnectX*").name -Confirm:$false            Get-NetAdapter -InterfaceDescription "Mellanox ConnectX*"        # Disable QLogic Nix            Disable-NetAdapter -Name $(Get-NetAdapter -InterfaceDescription "QLogic FastLinQ QL41262*").name -Confirm:$false            Get-NetAdapter -InterfaceDescription "QLogic FastLinQ QL41262*"    }}