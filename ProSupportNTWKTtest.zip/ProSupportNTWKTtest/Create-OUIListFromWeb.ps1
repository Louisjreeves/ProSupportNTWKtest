<# You running this script/function means you will not blame the author(s) if this breaks your stuff. 
This script/function is provided AS IS without warranty of any kind. Author(s) disclaim all implied 
warranties including, without limitation, any implied warranties of merchantability or of fitness for
 a particular purpose. The entire risk arising out of the use or performance of the sample scripts 
 and documentation remains with you. In no event shall author(s) be held liable for any damages 
 whatsoever (including, without limitation, damages for loss of business profits, business interruption, 
 loss of business information, or other pecuniary loss) arising out of the use of or inability to use 
 the script or documentation. Neither this script/function, nor any part of it other than those parts that 
 are explicitly copied from others, may be republished without author(s) express written permission. 
 Author(s) retain the right to alter this disclaimer at any time. For the most up to date version of 
 the disclaimer

 #>
#$LatestOUI = Get-Content -Path "$PSScriptRoot\oui_from_web.txt"
$LatestOUIs = (Invoke-WebRequest -Uri "http://linuxnet.ca/ieee/oui.txt").Content

$Output = ""

foreach($Line in $LatestOUIs -split '[\r\n]')
{
    if($Line -match "^[A-F0-9]{6}")
    {        
        # Line looks like: 2405F5     (base 16)		Integrated Device Technology (Malaysia) Sdn. Bhd.
        $Output += ($Line -replace '\s+', ' ').Replace(' (base 16) ', '|').Trim() + "`n"
    }
}

Out-File -InputObject $Output -FilePath "$PSScriptRoot\Resources\oui.txt"